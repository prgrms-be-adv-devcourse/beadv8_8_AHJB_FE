import { Link } from 'react-router-dom'
import type { AuctionSummary } from '@/types/auction'
import { useNow } from '@/lib/clock'
import { formatCountdown, formatWon } from '@/lib/format'
import { MANUFACTURER_LABELS } from '@/lib/labels'
import { auctionStatusBadge } from '@/lib/status'
import { Badge } from './Badge'
import { Icon } from './Icon'
import { Img } from './Img'
import { WishButton } from './WishButton'
import styles from './ProductCard.module.css'

/** 상품 상세 경로 */
export const productPath = (productId: number | string) => `/products/${productId}`

interface ProductCardProps {
  item: AuctionSummary
  /** 오른쪽 위 찜 버튼 (기본 true) */
  showWish?: boolean
  /** 가격 이름을 직접 정할 때 (입찰 수를 모르는 추천·검색 카드) */
  priceLabel?: string
}

/** 경매 상품 카드 */
export function ProductCard({ item, showWish = true, priceLabel }: ProductCardProps) {
  const now = useNow()
  // 무산 사유가 없으면 입찰 0건 = 유찰로 본다 (목록 API 에 failureReason 추가 전까지)
  const failureReason = item.failureReason ?? (item.status === 'FAILED' && item.bidCount === 0 ? 'NO_BID' : null)
  const badge = auctionStatusBadge(item.status, item.endAt, now, failureReason)
  /** 유찰은 낙찰가가 없어서 시작가를 보여 준다 */
  const noBidFailed = failureReason === 'NO_BID'
  const isLive = item.status === 'IN_PROGRESS' && item.endAt
  const remaining = isLive
    ? Date.parse(item.endAt!) - now
    : item.status === 'SCHEDULED' && item.startAt
      ? Date.parse(item.startAt) - now
      : 0
  const ended = item.status !== 'IN_PROGRESS' && item.status !== 'SCHEDULED'
  const showStatusBadge = badge.tone !== 'live' && item.status !== 'SCHEDULED'
  const canBuyNow = !!item.instantWinPrice && !ended

  return (
    <article className={`${styles.card} ${ended ? styles.ended : ''}`}>
      <Link to={productPath(item.productId)} className={styles.link}>
        <div className={styles.media}>
          <Img src={item.thumbnailUrl} alt={item.productName} className={styles.image} />
          {isLive || item.status === 'SCHEDULED' ? (
            <span
              className={`${styles.timer} ${badge.tone === 'closing' ? styles.timerHot : ''} ${item.status === 'SCHEDULED' ? styles.timerSoon : ''} num`}
            >
              <Icon name="clock" size={12} />
              {item.status === 'SCHEDULED'
                ? remaining > 0
                  ? `${formatCountdown(remaining)} 후 시작`
                  : '곧 오픈'
                : formatCountdown(remaining)}
            </span>
          ) : null}
        </div>
        <div className={styles.body}>
          {/* 경매 중이면 배지 없음. 마감 임박·종료 상태와 즉시 구매만 표시 */}
          {showStatusBadge || canBuyNow ? (
            <div className={styles.badges}>
              {showStatusBadge ? <Badge tone={badge.tone}>{badge.label}</Badge> : null}
              {canBuyNow ? <Badge variant="outline">즉시 구매</Badge> : null}
            </div>
          ) : null}
          <h3 className={styles.title}>{item.productName || '상품 정보 없음'}</h3>
          {item.manufacturer ? <p className={styles.meta}>{MANUFACTURER_LABELS[item.manufacturer]}</p> : null}
          <div className={styles.priceRow}>
            <span className={styles.priceLabel}>
              {priceLabel ?? (noBidFailed ? '유찰 · 시작가' : ended ? '낙찰' : item.bidCount ? '현재가' : '시작가')}
            </span>
            <span className={`${styles.price} num`}>{formatWon(item.currentPrice)}</span>
          </div>
          {item.bidCount || item.wishCount ? (
            <p className={`${styles.stats} num`}>
              {[item.bidCount ? `입찰 ${item.bidCount}` : null, item.wishCount ? `찜 ${item.wishCount}` : null]
                .filter(Boolean)
                .join(' · ')}
            </p>
          ) : null}
        </div>
      </Link>
      {showWish ? (
        <div className={styles.fav}>
          <WishButton productId={item.productId} compact />
        </div>
      ) : null}
    </article>
  )
}

/** 카드 자리표시 */
export function ProductCardSkeleton() {
  return (
    <div className={styles.card} aria-hidden="true">
      <div className={styles.skeletonMedia} />
      <div className={styles.body}>
        <span className={styles.skeletonLine} style={{ width: '40%' }} />
        <span className={styles.skeletonLine} style={{ width: '90%' }} />
        <span className={styles.skeletonLine} style={{ width: '60%' }} />
      </div>
    </div>
  )
}
